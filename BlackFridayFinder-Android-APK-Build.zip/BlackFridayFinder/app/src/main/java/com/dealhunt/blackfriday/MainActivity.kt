package com.dealhunt.blackfriday

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101114)
private val Panel = Color(0xFF1B1D22)
private val Gold = Color(0xFFFFC247)
private val Muted = Color(0xFFADB1BA)

data class Deal(
    val id: Int, val title: String, val retailer: String, val category: String,
    val price: Double, val oldPrice: Double, val url: String, val note: String
) {
    val saving: Int get() = (((oldPrice - price) / oldPrice) * 100).toInt()
}

private val sampleDeals = listOf(
    Deal(1, "Wireless noise-cancelling headphones", "Example Retailer", "Tech", 79.99, 129.99, "https://www.amazon.co.uk/", "Example offer – verify price"),
    Deal(2, "4K Smart TV 50 inch", "Example Retailer", "TVs", 299.00, 399.00, "https://www.currys.co.uk/", "Example offer – verify price"),
    Deal(3, "Games console bundle", "Example Retailer", "Gaming", 449.00, 499.00, "https://www.argos.co.uk/", "Example offer – verify price"),
    Deal(4, "Robot vacuum cleaner", "Example Retailer", "Home", 149.99, 229.99, "https://www.johnlewis.com/", "Example offer – verify price"),
    Deal(5, "Android smartphone 128GB", "Example Retailer", "Phones", 219.00, 279.00, "https://www.samsung.com/uk/", "Example offer – verify price"),
    Deal(6, "Kids building set", "Example Retailer", "Toys", 34.99, 49.99, "https://www.smythstoys.com/uk/en-gb", "Example offer – verify price")
)
private val categories = listOf("All", "Tech", "Phones", "TVs", "Gaming", "Home", "Toys")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DealApp() }
    }
}

@Composable
fun DealApp() {
    var tab by remember { mutableStateOf("Deals") }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    var favourites by remember { mutableStateOf(setOf<Int>()) }
    var selected by remember { mutableStateOf<Deal?>(null) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Ink, surface = Panel,
        onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            Column {
                Header()
                when {
                    selected != null -> DealDetail(selected!!, onBack = { selected = null },
                        isSaved = favourites.contains(selected!!.id),
                        onSave = { id -> favourites = if (id in favourites) favourites - id else favourites + id })
                    tab == "Premium" -> PremiumScreen()
                    tab == "Saved" -> DealList(
                        deals = sampleDeals.filter { it.id in favourites },
                        favourites = favourites,
                        onFavourite = { id -> favourites = favourites - id },
                        onOpen = { selected = it },
                        emptyMessage = "No saved deals yet. Tap the heart on a deal to save it."
                    )
                    else -> {
                        OutlinedTextField(
                            value = query, onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                            placeholder = { Text("Search deals, brands or products…", color = Muted) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Gold, unfocusedBorderColor = Color.DarkGray,
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White
                            )
                        )
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            categories.forEach { c ->
                                FilterChip(selected = category == c, onClick = { category = c },
                                    label = { Text(c, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Gold, selectedLabelColor = Ink,
                                        labelColor = Color.White
                                    ))
                            }
                        }
                        Text("Today's featured deals", Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
                            color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        val filtered = sampleDeals.filter {
                            (category == "All" || it.category == category) &&
                            (it.title.contains(query, true) || it.retailer.contains(query, true) || it.category.contains(query, true))
                        }
                        DealList(filtered, favourites, { id ->
                            favourites = if (id in favourites) favourites - id else favourites + id
                        }, { selected = it }, "No matching deals. Try another search or category.")
                    }
                }
                Spacer(Modifier.weight(1f))
                NavigationBar(containerColor = Panel) {
                    listOf("Deals", "Saved", "Premium").forEach { item ->
                        NavigationBarItem(selected = tab == item, onClick = { selected = null; tab = item },
                            icon = { Text(when(item) { "Deals" -> "🔥"; "Saved" -> "♥"; else -> "★" }) },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Gold, selectedTextColor = Gold,
                                indicatorColor = Color(0xFF393027), unselectedTextColor = Muted
                            ))
                    }
                }
            }
        }
    }
}

@Composable
fun Header() {
    Column(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("BLACK", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.width(6.dp))
            Text("FRIDAY", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            Text("UK DEALS", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Text("Find it. Compare it. Save money.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun DealList(
    deals: List<Deal>, favourites: Set<Int>, onFavourite: (Int) -> Unit,
    onOpen: (Deal) -> Unit, emptyMessage: String
) {
    if (deals.isEmpty()) {
        Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
            Text(emptyMessage, color = Muted)
        }
    } else {
        LazyColumn(contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(deals, key = { it.id }) { deal ->
                DealCard(deal, deal.id in favourites, { onFavourite(deal.id) }, { onOpen(deal) })
            }
        }
    }
}

@Composable
fun DealCard(deal: Deal, saved: Boolean, onSave: () -> Unit, onOpen: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).clickable { onOpen() }) {
            Text(deal.category.uppercase(), color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(deal.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
            Text(deal.retailer, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                Text("£%.2f".format(deal.price), color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(8.dp))
                Text("£%.2f".format(deal.oldPrice), color = Muted, fontSize = 12.sp)
                Spacer(Modifier.width(8.dp))
                Text("${deal.saving}% OFF", color = Color(0xFF9BE2A8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (saved) "♥" else "♡", color = if (saved) Gold else Muted, fontSize = 27.sp,
                modifier = Modifier.clickable { onSave() }.padding(8.dp))
            Text("VIEW", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onOpen() }.padding(6.dp))
        }
    }
}

@Composable
fun DealDetail(deal: Deal, onBack: () -> Unit, isSaved: Boolean, onSave: (Int) -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(20.dp)) {
        Text("← Back", color = Gold, modifier = Modifier.clickable { onBack() }.padding(bottom = 20.dp))
        Text(deal.category.uppercase(), color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(deal.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 25.sp,
            modifier = Modifier.padding(top = 8.dp))
        Text(deal.retailer, color = Muted, modifier = Modifier.padding(top = 8.dp))
        Text("£%.2f".format(deal.price), color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Black,
            modifier = Modifier.padding(top = 22.dp))
        Text("Was £%.2f • ${deal.saving}% lower".format(deal.oldPrice), color = Muted)
        Text(deal.note, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 16.dp))
        Button(onClick = {
            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(deal.url))) }
        }, modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) {
            Text("Visit retailer")
        }
        OutlinedButton(onClick = { onSave(deal.id) }, modifier = Modifier.fillMaxWidth()) {
            Text(if (isSaved) "Remove from saved" else "Save this deal")
        }
        Text("Always check the retailer's current price, delivery costs and terms before buying.",
            color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 18.dp))
    }
}

@Composable
fun PremiumScreen() {
    Column(Modifier.fillMaxWidth().padding(20.dp)) {
        Text("GO PREMIUM", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text("Never miss a better deal.", color = Color.White, fontSize = 27.sp,
            fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 8.dp))
        Text("Premium membership concept", color = Muted, modifier = Modifier.padding(top = 6.dp))
        listOf("Exclusive deal alerts", "Advanced price history", "More price-drop notifications",
            "Advanced retailer comparisons", "Personalised recommendations", "Ad-free browsing").forEach {
            Row(Modifier.padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("✓", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(it, color = Color.White, modifier = Modifier.padding(start = 12.dp))
            }
        }
        Text("Subscription checkout is not connected yet. Before publishing, configure a Google Play subscription product and verify purchases on a secure backend.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 24.dp))
    }
}
